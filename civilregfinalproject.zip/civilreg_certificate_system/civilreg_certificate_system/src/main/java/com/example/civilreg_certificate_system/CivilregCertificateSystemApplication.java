package com.example.civilreg_certificate_system;

import com.example.civilreg_certificate_system.Model.Birth;
import com.example.civilreg_certificate_system.Model.Death;
import com.example.civilreg_certificate_system.Model.Marriage;
import com.example.civilreg_certificate_system.Model.User;
import com.example.civilreg_certificate_system.Repository.BirthRepository;
import com.example.civilreg_certificate_system.Repository.DeathRepository;
import com.example.civilreg_certificate_system.Repository.MarriageRepository;
import com.example.civilreg_certificate_system.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.sql.Date;
import java.time.LocalDate;

@SpringBootApplication
public class CivilregCertificateSystemApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(CivilregCertificateSystemApplication.class, args);
	}
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private BirthRepository birthRepository;
	@Autowired
	private DeathRepository deathRepository;
	@Autowired
	private MarriageRepository marriageRepository;

	@Override
   public  void run(String...args) throws Exception {

//		User user = new User();
//		user.setUsername("Christian12?");
//		user.setEmail("cmadaoua@gmail.com");
//		user.setPassword("Christ12?");
//		user.setRole("Admin");
//		userRepository.save(user);
//
//	   User user1 = new User();
//	   user1.setUsername("Christian12?");
//	   user1.setEmail("madaoua@gmail.com");
//	   user1.setPassword("Christ12?");
//	   user1.setRole("Applicant");
//	   userRepository.save(user1);
//
//		User user2 = new User();
//		user2.setUsername("Madaoua12?");
//		user2.setEmail("cadaoua@gmail.com");
//		user2.setPassword("Christ12?");
//		user2.setRole("Government");
//		userRepository.save(user2);
//
//		Birth birth = new Birth();
//		birth.setFirstName("Joe");
//		birth.setLastName("Doe");
//		birth.setBirthDate(LocalDate.of(1990, 5, 15)); //
//		birth.setFatherName("John Doe Sr.");
//		birth.setFbirhtdate(LocalDate.of(1965, 3, 10));
//		birth.setFoccupation("Engineer");
//		birth.setMotherName("Jane Doe");
//		birth.setMbirthdate(LocalDate.of(1970, 8, 20));
//		birth.setMoccupation("Teacher");
//		birth.setDocumentPath("/path/to/Chris.pdf");
//		birth.setStatus("Active");
//
//		birthRepository.save(birth);
//
//		Marriage marriage = new Marriage();
//		marriage.setHusbandFirstName("John");
//		marriage.setHusbandLastName("Doe");
//		marriage.setWifeFirstName("Jane");
//		marriage.setWifeLastName("Doe");
//		marriage.setHusbandBirthDate(Date.valueOf(LocalDate.of(1985, 10, 20))); // Conversion LocalDate en Date
//		marriage.setWifeBirthDate(Date.valueOf(LocalDate.of(1990, 5, 15))); // Conversion LocalDate en Date
//		marriage.setMarriageDate(Date.valueOf(LocalDate.now())); // Date actuelle
//		marriage.setHusbandOccupation("Engineer");
//		marriage.setWifeOccupation("Teacher");
//		marriage.setWitness1Name("Witness1");
//		marriage.setWitness2Name("Witness2");
//		marriage.setPlaceOfMarriage("City");
//		marriage.setDocumentPath("/path/to/document.pdf");
//		marriage.setStatus("Active");
//
//		marriageRepository.save(marriage);


	}

}
