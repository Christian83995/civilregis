package com.example.civilreg_certificate_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    public void sendSignUpEmail(String to, String username) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject("Welcome to Civil Registry System / Bienvenue au Système de Registre Civil / مرحبًا بكم في نظام السجل المدني");

        String englishMessage = "Dear " + username + ",\n\nThank you for signing up with us. We are excited to have you on board!\n\nBest regards,\nCivil Registry System Team";
        String frenchMessage = "Cher " + username + ",\n\nMerci de vous être inscrit chez nous. Nous sommes ravis de vous avoir parmi nous!\n\nCordialement,\nÉquipe du Système de Registre Civil";
        String arabicMessage = "عزيزي " + username + "،\n\nشكرًا لتسجيلك معنا. نحن متحمسون لانضمامك إلينا!\n\nأطيب التحيات،\nفريق نظام السجل المدني";

        message.setText(englishMessage + "\n\n" + frenchMessage + "\n\n" + arabicMessage);

        mailSender.send(message);
    }

}