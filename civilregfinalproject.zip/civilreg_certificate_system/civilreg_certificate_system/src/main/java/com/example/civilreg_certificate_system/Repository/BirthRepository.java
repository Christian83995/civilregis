package com.example.civilreg_certificate_system.Repository;

import com.example.civilreg_certificate_system.Model.Birth;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BirthRepository extends JpaRepository<Birth, String> {
}
