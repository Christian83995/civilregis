package com.example.civilreg_certificate_system.Repository;

import com.example.civilreg_certificate_system.Model.Marriage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MarriageRepository extends JpaRepository<Marriage, String> {
}
