// Function to toggle the sidebar
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const content = document.querySelector('.content');
    sidebar.classList.toggle('close');
    content.classList.toggle('close');
}

// Add event listener to the menu icon
document.querySelector('.toggle-btn').addEventListener('click', toggleSidebar);
