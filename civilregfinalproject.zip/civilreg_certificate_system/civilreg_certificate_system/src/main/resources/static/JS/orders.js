const Orders = [
    {
        productName: 'JavaScript Tuto',
        productNumber: '85743',
        paymentStatus: 'Due',
        status: 'Pending'
    },
    {
        productName: 'CSS Full Course',
        productNumber: '97245',
        paymentStatus: 'Refunded',
        status: 'Declined'
    },
    {
        productName: 'HTML Tuto',
        productNumber: '36452',
        paymentStatus: 'Paid',
        status: 'Active'
    }
]